
import { ReactNode, useState } from "react";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Camera, Search, LogOut } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";

interface MainLayoutProps {
  children: ReactNode;
  activeTab: "capture" | "view";
}

const MainLayout = ({ children, activeTab }: MainLayoutProps) => {
  const navigate = useNavigate();
  const { logout } = useAuth();
  
  const handleTabChange = (value: string) => {
    navigate(`/home/${value}`);
  };
  
  const handleLogout = async () => {
    try {
      await logout();
      navigate("/login");
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-app-light-gray">
      {/* Header */}
      <motion.header 
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass glass-border border-b z-10 px-4 py-4 flex justify-between items-center"
      >
        <h1 className="text-xl font-semibold text-app-dark-gray">GPS Media Manager</h1>
        <button 
          onClick={handleLogout}
          className="text-app-gray p-2 rounded-full hover:bg-app-light-gray transition-colors"
        >
          <LogOut size={20} />
        </button>
      </motion.header>

      {/* Main Content */}
      <main className="flex-1 overflow-hidden">
        <AnimatePresence mode="wait">
          <motion.div 
            key={activeTab}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="h-full"
          >
            {children}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Footer Tabs */}
      <motion.div 
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass glass-border border-t"
      >
        <Tabs 
          defaultValue={activeTab} 
          value={activeTab} 
          onValueChange={handleTabChange} 
          className="w-full"
        >
          <TabsList className="grid w-full grid-cols-2 h-16">
            <TabsTrigger 
              value="capture" 
              className="flex items-center justify-center gap-2 data-[state=active]:text-app-blue"
            >
              <Camera size={20} />
              <span>Capture</span>
            </TabsTrigger>
            <TabsTrigger 
              value="view" 
              className="flex items-center justify-center gap-2 data-[state=active]:text-app-blue"
            >
              <Search size={20} />
              <span>View</span>
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </motion.div>
    </div>
  );
};

export default MainLayout;
