
import { Loader2 } from "lucide-react";
import { MediaItem } from "@/types/media";
import MediaCard from "./MediaCard";

interface MediaGridProps {
  isLoading: boolean;
  media: MediaItem[];
  searchQuery: string;
  onMediaClick: (media: MediaItem) => void;
}

const MediaGrid = ({ isLoading, media, searchQuery, onMediaClick }: MediaGridProps) => {
  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-48">
        <Loader2 className="h-8 w-8 animate-spin text-app-blue" />
      </div>
    );
  }
  
  if (media.length === 0) {
    return (
      <div className="text-center py-12 text-app-gray">
        {searchQuery ? (
          <p>No media found matching "{searchQuery}"</p>
        ) : (
          <p>No media found. Try capturing some photos first.</p>
        )}
      </div>
    );
  }
  
  return (
    <div className="grid grid-cols-2 gap-3">
      {media.map((mediaItem) => (
        <MediaCard 
          key={mediaItem.id} 
          media={mediaItem} 
          onClick={onMediaClick} 
        />
      ))}
    </div>
  );
};

export default MediaGrid;
