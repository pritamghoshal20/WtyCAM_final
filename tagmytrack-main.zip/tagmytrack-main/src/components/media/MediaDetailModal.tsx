
import { format } from "date-fns";
import { Map, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { MediaItem } from "@/types/media";

interface MediaDetailModalProps {
  media: MediaItem | null;
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
}

const MediaDetailModal = ({ media, isOpen, onOpenChange }: MediaDetailModalProps) => {
  if (!media) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="glass glass-border max-w-lg rounded-2xl p-0 overflow-hidden">
        <div>
          <div className="relative aspect-video">
            <img 
              src={media.imageUrl} 
              alt={`Media ${media.chassisId}`} 
              className="w-full h-full object-cover"
              onError={(e) => {
                console.error(`Failed to load image: ${media.imageUrl}`);
                e.currentTarget.src = "/placeholder.svg";
              }}
            />
          </div>
          
          <div className="p-4 space-y-4">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-lg font-medium">{media.chassisId}</h3>
                <p className="text-sm text-app-gray">Job #{media.jobNumber}</p>
              </div>
              <Button variant="outline" size="sm" onClick={() => onOpenChange(false)}>
                Close
              </Button>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm text-app-gray">
                <Calendar size={16} />
                <span>{format(media.timestamp, "PPpp")}</span>
              </div>
              
              <div className="flex items-center gap-2 text-sm text-app-gray">
                <Map size={16} />
                <span>
                  {media.location?.latitude && media.location?.longitude
                    ? `${media.location.latitude.toFixed(6)}, ${media.location.longitude.toFixed(6)}`
                    : media.location?.address || "Location not available"}
                </span>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default MediaDetailModal;
