
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";

interface SearchBarProps {
  value: string;
  onChange: (value: string) => void;
}

const SearchBar = ({ value, onChange }: SearchBarProps) => {
  return (
    <div className="p-4 sticky top-0 z-10 glass glass-border border-b">
      <div className="relative">
        <Search className="absolute left-3 top-3 h-4 w-4 text-app-gray" />
        <Input
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="Search by Chassis ID or Job Number..."
          className="pl-9 h-10"
        />
      </div>
    </div>
  );
};

export default SearchBar;
