
import { motion } from "framer-motion";
import { MediaItem } from "@/types/media";

interface MediaCardProps {
  media: MediaItem;
  onClick: (media: MediaItem) => void;
}

const MediaCard = ({ media, onClick }: MediaCardProps) => {
  return (
    <motion.div
      whileHover={{ scale: 1.03 }}
      whileTap={{ scale: 0.98 }}
      onClick={() => onClick(media)}
      className="relative rounded-xl overflow-hidden bg-white shadow-md glass-border cursor-pointer"
    >
      <div className="aspect-square overflow-hidden">
        <img 
          src={media.imageUrl} 
          alt={`Media ${media.chassisId}`} 
          className="w-full h-full object-cover"
          onError={(e) => {
            console.error(`Failed to load image: ${media.imageUrl}`);
            e.currentTarget.src = "/placeholder.svg";
          }}
        />
        {media.type === "video" && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/20">
            <div className="w-12 h-12 rounded-full bg-white/30 backdrop-blur-sm flex items-center justify-center">
              <div className="w-0 h-0 border-y-8 border-y-transparent border-l-12 border-l-white ml-1" />
            </div>
          </div>
        )}
      </div>
      <div className="p-2">
        <p className="font-medium truncate">{media.chassisId}</p>
        <p className="text-xs text-app-gray truncate">
          Job #{media.jobNumber}
        </p>
      </div>
    </motion.div>
  );
};

export default MediaCard;
