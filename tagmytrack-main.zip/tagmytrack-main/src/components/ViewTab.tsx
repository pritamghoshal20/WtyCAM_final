
import { useState } from "react";
import { AnimatePresence } from "framer-motion";
import { useAuth } from "@/hooks/useAuth";
import { useMediaData } from "@/hooks/useMediaData";
import { MediaItem } from "@/types/media";
import SearchBar from "./media/SearchBar";
import MediaGrid from "./media/MediaGrid";
import MediaDetailModal from "./media/MediaDetailModal";

const ViewTab = () => {
  const { user } = useAuth();
  const { filteredMedia, searchQuery, setSearchQuery, isLoading } = useMediaData(user?.uid);
  const [selectedMedia, setSelectedMedia] = useState<MediaItem | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleMediaClick = (media: MediaItem) => {
    setSelectedMedia(media);
    setIsModalOpen(true);
  };

  return (
    <div className="flex flex-col h-full">
      <SearchBar value={searchQuery} onChange={setSearchQuery} />
      
      <div className="flex-1 overflow-y-auto p-4">
        <AnimatePresence>
          <MediaGrid 
            isLoading={isLoading} 
            media={filteredMedia} 
            searchQuery={searchQuery}
            onMediaClick={handleMediaClick} 
          />
        </AnimatePresence>
      </div>

      <MediaDetailModal 
        media={selectedMedia} 
        isOpen={isModalOpen} 
        onOpenChange={setIsModalOpen} 
      />
    </div>
  );
};

export default ViewTab;
