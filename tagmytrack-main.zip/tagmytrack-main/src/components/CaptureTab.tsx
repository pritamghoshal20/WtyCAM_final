
import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Camera as CameraIcon, Video, X, Loader2, MapPin } from "lucide-react";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { Camera, CameraResultType, CameraSource, Photo } from '@capacitor/camera';
import { useNavigate } from "react-router-dom";
import { firestore, storage } from "@/lib/firebase";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";
import { useAuth } from "@/hooks/useAuth";

const CaptureTab = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [captureType, setCaptureType] = useState<"photo" | "video" | null>(null);
  const [chassisId, setChassisId] = useState("");
  const [jobNumber, setJobNumber] = useState("");
  const [isCapturing, setIsCapturing] = useState(false);
  const [capturedImageUrl, setCapturedImageUrl] = useState<string | null>(null);
  const [previewMode, setPreviewMode] = useState(false);
  const [currentLocation, setCurrentLocation] = useState<{latitude: number, longitude: number} | null>(null);
  const [capturedPhoto, setCapturedPhoto] = useState<Photo | null>(null);
  const [isWebFallback, setIsWebFallback] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const navigate = useNavigate();
  const { user } = useAuth();
  const mediaStreamRef = useRef<MediaStream | null>(null);

  const resetForm = () => {
    setChassisId("");
    setJobNumber("");
    setCaptureType(null);
    setIsModalOpen(false);
    setCapturedImageUrl(null);
    setCapturedPhoto(null);
    setPreviewMode(false);
    setCurrentLocation(null);
    setIsWebFallback(false);
    stopWebCamera();
  };

  const stopWebCamera = () => {
    // Stop any active media tracks if web camera is being used
    if (mediaStreamRef.current) {
      const tracks = mediaStreamRef.current.getTracks();
      tracks.forEach(track => track.stop());
      mediaStreamRef.current = null;
    }
    
    if (videoRef.current && videoRef.current.srcObject) {
      videoRef.current.srcObject = null;
    }
  };

  const getCurrentLocation = (): Promise<{latitude: number, longitude: number}> => {
    return new Promise((resolve, reject) => {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          resolve({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude
          });
        },
        (error) => {
          console.error("Error getting location:", error);
          reject(error);
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
      );
    });
  };

  const initWebCamera = async () => {
    try {
      setIsWebFallback(true);
      
      // Try to get location first
      try {
        const location = await getCurrentLocation();
        setCurrentLocation(location);
        console.log("Got location:", location);
      } catch (error) {
        console.error("Failed to get location:", error);
        toast.error("Couldn't get your location. Photo will not be GPS-tagged.");
      }

      // Request camera access
      console.log("Requesting camera access...");
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment' }, 
        audio: false 
      });
      
      console.log("Camera access granted");
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        mediaStreamRef.current = stream;
      }
    } catch (error) {
      console.error("Web camera access error:", error);
      toast.error("Failed to access camera. Please check permissions.");
      setIsWebFallback(false);
      setIsModalOpen(true);
    }
  };

  const captureWebPhoto = () => {
    if (!videoRef.current || !canvasRef.current) {
      console.error("Video or canvas ref is not available");
      return;
    }
    
    const video = videoRef.current;
    const canvas = canvasRef.current;
    
    // Set canvas dimensions to match video
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    
    // Draw the current frame to canvas
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    }
    
    // Get data URL from canvas
    const dataUrl = canvas.toDataURL('image/jpeg', 0.9);
    console.log("Captured image from web camera");
    setCapturedImageUrl(dataUrl);
    setPreviewMode(true);
    setIsWebFallback(false);
    stopWebCamera();
  };

  const takePicture = async () => {
    console.log("Taking picture...");
    setIsCapturing(true);
    
    try {
      // First try to get current location
      try {
        console.log("Getting location...");
        const location = await getCurrentLocation();
        console.log("Location obtained:", location);
        setCurrentLocation(location);
      } catch (error) {
        console.error("Failed to get location:", error);
        toast.error("Couldn't get your location. Photo will not be GPS-tagged.");
      }
      
      // Close the modal while we prepare the camera
      setIsModalOpen(false);

      // Try to use Capacitor Camera first
      try {
        console.log("Checking camera permissions...");
        const permissionStatus = await Camera.checkPermissions();
        console.log("Permission status:", permissionStatus);
        
        if (permissionStatus.camera !== 'granted') {
          console.log("Requesting camera permission...");
          const requestResult = await Camera.requestPermissions();
          console.log("Permission request result:", requestResult);
          
          if (requestResult.camera !== 'granted') {
            throw new Error("Camera permission denied");
          }
        }

        console.log("Taking picture with Capacitor Camera...");
        const image = await Camera.getPhoto({
          quality: 90,
          allowEditing: false,
          resultType: CameraResultType.Uri,
          source: CameraSource.Camera,
        });

        console.log("Photo taken successfully:", image);
        
        // Store the photo object for later use
        setCapturedPhoto(image);
        
        // Set the image URL for preview
        if (image.webPath) {
          setCapturedImageUrl(image.webPath);
          setPreviewMode(true);
        } else {
          throw new Error("No image path returned");
        }

        return;
      } catch (error: any) {
        console.error("Capacitor camera error:", error);
        
        // If we get the "Not implemented on web" error, fall back to web camera
        if (error?.message?.includes("Not implemented on web") || 
            error?.message?.includes("Camera plugin not implemented") || 
            error?.message?.includes("Capacitor plugin not available")) {
          console.log("Falling back to web camera");
          await initWebCamera();
          return;
        } else {
          throw error;
        }
      }
    } catch (error) {
      console.error("Camera error:", error);
      toast.error("Failed to access camera. Please check permissions.");
      setIsModalOpen(true); // Reopen the modal on error
      setIsCapturing(false);
    } finally {
      if (!isWebFallback) {
        setIsCapturing(false);
      }
    }
  };

  const saveToFirebase = async () => {
    try {
      if (!user) {
        toast.error("You must be logged in to save captures");
        return;
      }

      let blob: Blob;
      
      if (capturedPhoto && capturedPhoto.webPath) {
        // If we have a Capacitor photo, use that
        const response = await fetch(capturedPhoto.webPath);
        blob = await response.blob();
      } else if (capturedImageUrl && capturedImageUrl.startsWith('data:')) {
        // If we have a data URL from web camera, convert it to blob
        const response = await fetch(capturedImageUrl);
        blob = await response.blob();
      } else {
        toast.error("No photo to upload");
        return;
      }

      // Create a reference to storage with a unique filename
      const filename = `${user.uid}/${Date.now()}_${chassisId}.jpg`;
      const storageRef = ref(storage, `captures/${filename}`);

      // Upload to Firebase Storage
      const uploadSnapshot = await uploadBytes(storageRef, blob);
      const downloadUrl = await getDownloadURL(uploadSnapshot.ref);

      // Save metadata to Firestore
      await addDoc(collection(firestore, "captures"), {
        userId: user.uid,
        chassisId: chassisId,
        jobNumber: jobNumber,
        type: captureType,
        location: currentLocation,
        imageUrl: downloadUrl,
        createdAt: serverTimestamp(),
      });

      return downloadUrl;
    } catch (error) {
      console.error("Firebase save error:", error);
      throw error;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!chassisId.trim() || !jobNumber.trim()) {
      toast.error("Please fill all required fields");
      return;
    }
    
    try {
      await takePicture();
    } catch (error) {
      console.error("Capture error:", error);
      toast.error("Failed to capture. Please try again.");
    }
  };

  const confirmCapture = async () => {
    try {
      setIsCapturing(true);
      
      if (capturedImageUrl) {
        await saveToFirebase();
        toast.success(`Photo saved successfully with GPS data`);
        
        // Navigate to view tab to see the capture
        navigate("/home/view");
      }
      
      resetForm();
    } catch (error) {
      console.error("Save error:", error);
      toast.error("Failed to save capture. Please try again.");
    } finally {
      setIsCapturing(false);
    }
  };

  const cancelCapture = () => {
    setCapturedImageUrl(null);
    setCapturedPhoto(null);
    setPreviewMode(false);
  };

  const handleCaptureClick = (type: "photo" | "video") => {
    setCaptureType(type);
    setIsModalOpen(true);
  };

  // Clean up resources when component unmounts
  useEffect(() => {
    return () => {
      stopWebCamera();
    };
  }, []);

  return (
    <div className="flex flex-col h-full p-4">
      <h2 className="text-xl font-medium mb-6 text-center text-app-dark-gray">
        Capture GPS-Tagged Media
      </h2>
      
      <div className="flex-1 flex flex-col justify-center gap-6 max-w-sm mx-auto w-full">
        <motion.div
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          transition={{ type: "spring", stiffness: 400, damping: 17 }}
        >
          <Button 
            onClick={() => handleCaptureClick("photo")}
            className="w-full py-8 text-lg gap-3 bg-app-blue hover:bg-app-blue/90 shadow-lg"
          >
            <CameraIcon size={24} />
            <span>Capture Photo</span>
          </Button>
        </motion.div>
        
        <motion.div
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          transition={{ type: "spring", stiffness: 400, damping: 17 }}
        >
          <Button 
            onClick={() => handleCaptureClick("video")}
            className="w-full py-8 text-lg gap-3 bg-app-light-blue hover:bg-app-light-blue/90 shadow-lg"
          >
            <Video size={24} />
            <span>Capture Video</span>
          </Button>
        </motion.div>
      </div>

      {/* Information Form Dialog */}
      <Dialog open={isModalOpen && !previewMode && !isWebFallback} onOpenChange={(open) => {
        if (!open) resetForm();
        setIsModalOpen(open);
      }}>
        <DialogContent className="glass glass-border max-w-md rounded-2xl">
          <DialogHeader>
            <DialogTitle className="text-center">
              {captureType === "photo" ? "Capture Photo" : "Record Video"}
            </DialogTitle>
            <DialogDescription className="text-center">
              Enter details for this {captureType === "photo" ? "photo" : "video"} capture
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={handleSubmit} className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="chassisId">Chassis ID / Registration Number*</Label>
              <Input
                id="chassisId"
                value={chassisId}
                onChange={(e) => setChassisId(e.target.value)}
                placeholder="e.g., ABC123456"
                className="h-12"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="jobNumber">Job Number*</Label>
              <Input
                id="jobNumber"
                value={jobNumber}
                onChange={(e) => setJobNumber(e.target.value)}
                placeholder="e.g., 12345"
                type="text"
                className="h-12"
                required
              />
            </div>
            
            <DialogFooter className="mt-6 gap-3 flex-col sm:flex-col">
              <Button
                type="submit"
                className="w-full h-12 bg-app-blue hover:bg-app-blue/90"
                disabled={isCapturing}
              >
                {isCapturing ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>
                    {captureType === "photo" ? "Take Photo" : "Record Video"}
                  </>
                )}
              </Button>
              
              <Button
                type="button"
                variant="outline"
                onClick={resetForm}
                className="w-full h-12"
                disabled={isCapturing}
              >
                Cancel
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Web Camera Dialog */}
      <Dialog open={isWebFallback} onOpenChange={(open) => {
        if (!open) resetForm();
      }}>
        <DialogContent className="glass glass-border max-w-md rounded-2xl">
          <DialogHeader>
            <DialogTitle className="text-center">
              Camera Access
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 py-2">
            <div className="relative rounded-lg overflow-hidden aspect-[4/3] bg-black">
              <video 
                ref={videoRef} 
                autoPlay 
                playsInline 
                className="w-full h-full object-cover"
              />
              {currentLocation && (
                <div className="absolute bottom-2 left-2 bg-black/70 px-2 py-1 rounded-md text-white text-xs flex items-center">
                  <MapPin size={12} className="mr-1" />
                  <span>GPS Tagged</span>
                </div>
              )}
              <canvas ref={canvasRef} className="hidden" />
            </div>
            
            <DialogFooter className="mt-6 gap-3 flex-col sm:flex-col">
              <Button
                type="button"
                onClick={captureWebPhoto}
                className="w-full h-12 bg-app-blue hover:bg-app-blue/90"
              >
                Take Photo
              </Button>
              
              <Button
                type="button"
                variant="outline"
                onClick={resetForm}
                className="w-full h-12"
              >
                Cancel
              </Button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>

      {/* Preview Dialog */}
      <Dialog open={previewMode} onOpenChange={(open) => {
        if (!open) resetForm();
      }}>
        <DialogContent className="glass glass-border max-w-md rounded-2xl">
          <DialogHeader>
            <DialogTitle className="text-center">
              Preview Capture
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 py-2">
            {capturedImageUrl && (
              <div className="relative rounded-lg overflow-hidden aspect-[4/3] bg-black">
                <img 
                  src={capturedImageUrl} 
                  alt="Captured photo" 
                  className="w-full h-full object-contain"
                />
                {currentLocation && (
                  <div className="absolute bottom-2 left-2 bg-black/70 px-2 py-1 rounded-md text-white text-xs flex items-center">
                    <MapPin size={12} className="mr-1" />
                    <span>GPS Tagged</span>
                  </div>
                )}
              </div>
            )}
            
            <div className="space-y-2">
              <p className="text-sm text-gray-500">
                Chassis ID: <span className="font-medium text-gray-700">{chassisId}</span>
              </p>
              <p className="text-sm text-gray-500">
                Job Number: <span className="font-medium text-gray-700">{jobNumber}</span>
              </p>
              {currentLocation && (
                <p className="text-sm text-gray-500">
                  Location: <span className="font-medium text-gray-700">
                    {currentLocation.latitude.toFixed(6)}, {currentLocation.longitude.toFixed(6)}
                  </span>
                </p>
              )}
            </div>
            
            <DialogFooter className="mt-6 gap-3 flex-col sm:flex-col">
              <Button
                type="button"
                onClick={confirmCapture}
                className="w-full h-12 bg-app-blue hover:bg-app-blue/90"
                disabled={isCapturing}
              >
                {isCapturing ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Saving...
                  </>
                ) : (
                  "Save Capture"
                )}
              </Button>
              
              <Button
                type="button"
                variant="outline"
                onClick={cancelCapture}
                className="w-full h-12"
                disabled={isCapturing}
              >
                Retake
              </Button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default CaptureTab;
