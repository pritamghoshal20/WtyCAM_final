
import { useState, useEffect } from "react";
import { collection, query, where, getDocs, orderBy } from "firebase/firestore";
import { firestore } from "@/lib/firebase";
import { MediaItem } from "@/types/media";
import { toast } from "sonner";

export const useMediaData = (userId: string | undefined) => {
  const [media, setMedia] = useState<MediaItem[]>([]);
  const [filteredMedia, setFilteredMedia] = useState<MediaItem[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  // Fetch media data from Firestore
  useEffect(() => {
    const fetchData = async () => {
      if (!userId) {
        return;
      }
      
      try {
        setIsLoading(true);
        console.log("Fetching media data from Firestore...");
        
        const capturesRef = collection(firestore, "captures");
        const q = query(
          capturesRef,
          where("userId", "==", userId),
          orderBy("createdAt", "desc")
        );
        
        const querySnapshot = await getDocs(q);
        const mediaData: MediaItem[] = [];
        
        querySnapshot.forEach((doc) => {
          const data = doc.data();
          console.log("Document data:", data);
          
          // Convert Firestore timestamp to Date
          const timestamp = data.createdAt?.toDate() || new Date();
          
          // Add to media data only if required fields exist
          if (data.imageUrl) {
            mediaData.push({
              id: doc.id,
              chassisId: data.chassisId || "",
              jobNumber: data.jobNumber || "",
              timestamp: timestamp,
              location: data.location || { address: "Location not available" },
              type: data.type || "photo",
              imageUrl: data.imageUrl || ""
            });
          } else {
            console.log(`Skipping document ${doc.id} due to missing imageUrl`);
          }
        });
        
        console.log(`Fetched ${mediaData.length} media items`);
        setMedia(mediaData);
        setFilteredMedia(mediaData);
      } catch (error) {
        console.error("Error fetching data:", error);
        toast.error("Failed to load media");
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchData();
  }, [userId]);

  // Filter media based on search query
  useEffect(() => {
    if (!searchQuery.trim()) {
      setFilteredMedia(media);
      return;
    }
    
    setIsLoading(true);
    
    const query = searchQuery.toLowerCase().trim();
    console.log(`Filtering media with query: "${query}"`);
    
    const filtered = media.filter(item => {
      const chassisMatch = item.chassisId.toLowerCase().includes(query);
      const jobMatch = item.jobNumber.toLowerCase().includes(query);
      
      console.log(`Item ${item.id}: chassisId=${item.chassisId}, jobNumber=${item.jobNumber}, matches=${chassisMatch || jobMatch}`);
      
      return chassisMatch || jobMatch;
    });
    
    console.log(`Found ${filtered.length} matching items`);
    setFilteredMedia(filtered);
    setIsLoading(false);
  }, [searchQuery, media]);

  return { media, filteredMedia, searchQuery, setSearchQuery, isLoading };
};
