
export interface MediaItem {
  id: string;
  chassisId: string;
  jobNumber: string;
  timestamp: Date;
  location?: { 
    latitude?: number; 
    longitude?: number;
    address?: string;
  };
  type: string;
  imageUrl: string;
}
