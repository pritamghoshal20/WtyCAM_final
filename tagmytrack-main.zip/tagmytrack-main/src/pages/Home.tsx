
import { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import MainLayout from "@/components/MainLayout";
import CaptureTab from "@/components/CaptureTab";
import ViewTab from "@/components/ViewTab";
import { useAuth } from "@/hooks/useAuth";

const Home = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, loading } = useAuth();
  const [activeTab, setActiveTab] = useState<"capture" | "view">("capture");

  useEffect(() => {
    // Redirect to login if not authenticated
    if (!loading && !user) {
      navigate("/login");
      return;
    }

    // Parse active tab from URL path
    const path = location.pathname;
    if (path.includes("/view")) {
      setActiveTab("view");
    } else {
      setActiveTab("capture");
    }
  }, [user, loading, navigate, location.pathname]);

  // Show nothing while checking authentication
  if (loading) return null;

  return (
    <MainLayout activeTab={activeTab}>
      {activeTab === "capture" ? <CaptureTab /> : <ViewTab />}
    </MainLayout>
  );
};

export default Home;
