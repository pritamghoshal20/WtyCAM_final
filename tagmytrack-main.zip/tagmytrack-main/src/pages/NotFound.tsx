
import { useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

const NotFound = () => {
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname
    );
  }, [location.pathname]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-app-light-gray to-white p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="glass glass-border rounded-3xl p-8 text-center max-w-sm w-full"
      >
        <motion.h1 
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.2, type: "spring" }}
          className="text-7xl font-bold text-app-blue mb-6"
        >
          404
        </motion.h1>
        
        <h2 className="text-xl font-medium text-app-dark-gray mb-3">Page Not Found</h2>
        
        <p className="text-app-gray mb-8">
          The page you're looking for doesn't exist or has been moved.
        </p>
        
        <Button 
          onClick={() => navigate("/")}
          className="w-full bg-app-blue hover:bg-app-blue/90"
        >
          Return to Home
        </Button>
      </motion.div>
    </div>
  );
};

export default NotFound;
