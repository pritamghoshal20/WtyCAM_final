
import { initializeApp } from "firebase/app";
import { getAuth, connectAuthEmulator } from "firebase/auth";
import { getFirestore, connectFirestoreEmulator } from "firebase/firestore";
import { getStorage, connectStorageEmulator } from "firebase/storage";
import { getDatabase, connectDatabaseEmulator } from "firebase/database";

// Replace this configuration with your Firebase project details
// You can find these details in your Firebase project settings
const firebaseConfig = {
  apiKey: "AIzaSyAwKvH1YqI4Ije_PlUdqtRcuoThH8_P6No",
  authDomain: "warrantycam-e96cd.firebaseapp.com",
  projectId: "warrantycam-e96cd",
  storageBucket: "warrantycam-e96cd.firebasestorage.app",
  messagingSenderId: "368003280574",
  appId: "1:368003280574:web:26e9d77db86e91deb0f8ef",
  measurementId: "G-HE77G9ET88"
};


// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const firestore = getFirestore(app);
const storage = getStorage(app);
const database = getDatabase(app);

// Enable Firebase emulators if in development
// This allows for local testing without connecting to production Firebase
if (import.meta.env.DEV) {
  console.log("Using Firebase emulators");
  // Uncomment these lines if you want to use Firebase emulators
  // connectAuthEmulator(auth, "http://localhost:9099");
  // connectFirestoreEmulator(firestore, "localhost", 8080);
  // connectStorageEmulator(storage, "localhost", 9199);
  // connectDatabaseEmulator(database, "localhost", 9000);
}

export { app, auth, firestore, storage, database };
